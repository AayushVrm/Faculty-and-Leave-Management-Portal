# Faculty-Management-Portal

This is a flask based web application to manage Faculty affairs mainly leave application and showcasing faculty profiles to the users. This was completed as the course project for 'CSL 301​ ​ - ​ Introduction to Database Systems'. Project specifications can be found in the file Project_Specification.pdf.

**Tools/frameworks used** : Flask, MongoDB, PostgreSQL, JavaScript, HTML, CSS

#### How to run
> $python3 app.py
