from tkinter import *
from tkinter import ttk
from PIL import Image, ImageTk

class Student:
    def __init__(self, root, ):
        self.root = root
        self.root.geometry("1530x790+0+0")
        self.root.title("STUDENT MANAGEMENT SYSTEM")
        # #0st
        #  img=Image.open(r"college_images\7th.jpg")
        #  img=img.resize((540,160),Image.ANTIALIAS)
        #  self.photoimg=ImageTk.PhotoImage(img)
        #
        #  self.btn_1=Button(self.root,image=self.photoimg,cursor="hand2")
        #  self.btn_1.place(x=540,y=0,width=540,height=160)

        # 1st
        img = Image.open(r"college_images\11th.jpg")
        img = img.resize((540, 160), Image.ANTIALIAS)
        self.photoimg = ImageTk.PhotoImage(img)

        self.btn_1 = Button(self.root, image=self.photoimg, cursor="hand2")
        self.btn_1.place(x=540, y=0, width=540, height=160)

        # 2nd
        img_2 = Image.open(r"college_images\5th.jpg")
        img_2 = img.resize((540, 160), Image.ANTIALIAS)
        self.photoimg = ImageTk.PhotoImage(img_2)

        self.btn_2 = Button(self.root, image=self.photoimg, cursor="hand2")
        self.btn_2.place(x=540, y=0, width=540, height=160)

        # 3st
        img_3 = Image.open(r"college_images\6th.jpg")
        img_3 = img.resize((540, 160), Image.ANTIALIAS)
        self.photoimg_3 = ImageTk.PhotoImage(img_3)

        self.btn_3 = Button(self.root, image=self.photoimg, cursor="hand2")
        self.btn_3.place(x=1000, y=0, width=540, height=160)

        # bg image
        img = Image.open(r"college_images\university.jpg")
        img = img.resize((1530, 710), Image.ANTIALIAS)
        self.photoimg_4 = ImageTk.PhotoImage(img_3)

        bg_lbl = Button(self.root, image=self.photoimg, relief=RIDGE)
        bg_lbl.place(x=0, y=160, width=1530, height=710)

        lbl_title = Label(bg_lbl, text="FACULTY MANAGEMENT SYSTEM", font=("times new roman", 37, "bold"), fg="blue",
                          bg="white")
        lbl_title.place(x=0, y=0, width=1530, height=50)

        # manage frame
        Manage_frame = Frame(bg_lbl, bd=2, relief=RIDGE, bg="white")
        Manage_frame.place(x=15, y=55, width=1500, height=560)

        # left frame
        DataLeftFrame = LabelFrame(Manage_frame, bd=4, relief=RIDGE, padx=2, text="TEACHERS Information",font=("times new roman", 12, "bold"), fg="red", bg="white")
        DataLeftFrame.place(x=10, y=10, width=660, height=560)

        # img1
        img_5 = Image.open(r"college_images\3rd.jpg")
        img_5 = img_5.resize((650, 120), Image.ANTIALIAS)
        self.photoimg_5 = ImageTk.PhotoImage(img_5)

        my_img = Label(DataLeftFrame, image=self.photoimg_5, bd=2, relief=RIDGE)
        my_img.place(x=0, y=0, width=650, height=120)

        # current course LabelFrame information
        std_lbl_info_frame=LabelFrame(Manage_frame, bd=4, relief=RIDGE, padx=2, text="TEACHERS Information",
                                   font=("times new roman", 12, "bold"), fg="red", bg="white")
        std_lbl_info_frame.place(x=10, y=10, width=660, height=560)

        #labels
        lbl_dep=Label(std_lbl_info_frame,text="Department",font=("arial",12,"bold"),bg="white")
        lbl_dep.grid(row=0,column=0,padx=2,sticky=W)

        combo_dep=ttk.Combobox(std_lbl_info_frame,font=("arial",12,"bold"),width=17,state="readonly")
        combo_dep["value"]=("Select Department","Computer Science and Engineering","Elctronic and Communication Engineering","Aeronautical Engineering","Mechanical Engineering")
        combo_dep.current(0)
        combo_dep.grid(row=0,column=1,padx=2,pady=10,sticky=W)

        #Course
        course_std=Label(std_lbl_info_frame,font=("arial",12,"bold"),text="Courses:", bg="white")
        course_std.grid(row=0,column=2,sticky=W,padx=2,pady=10)

        com_txtcourse_std=ttk.Combobox(std_lbl_info_frame,state="readonly",font=("arial",12,"bold"),width=17)

        com_txtcourse_std['value']=("Select Course","FE","SE","TE","BE")
        com_txtcourse_std.current(0)
        com_txtcourse_std.grid(row=0,column=3,sticky=W,padx=2,pady=10)

        # year
        currunt_year=Label(std_lbl_info_frame,font=("arial",12,"bold"),text="Year:",bg="white")
        currunt_year.grid(row=1,column=0,sticky=W,padx=2,pady=10)

        com_txt_currunt_year=ttk.Combobox(std_lbl_info_frame,state="readonly",font=("arial",12,"bold"),width=17)

        com_txt_currunt_year['value']



        # Right frame
        DataRightFrame = LabelFrame(Manage_frame, bd=4, relief=RIDGE, padx=2, text="TEACHERS Information",font=("times new roman", 12, "bold"), fg="red", bg="white")
        DataRightFrame.place(x=680, y=10, width=870, height=540)


if __name__ == "__main__":
    root = Tk()
    obj = Student(root)
    root.mainloop()

# from logging import root
# from tkinter import Label, Frame
# import tkinter as tk
# from PIL import Image
#
#
# class Employee:
#     def __init__(self, master):
#         self.root = master
#         self.root.geometry("1530x790+0+0")
#         self.root.title('Employee Management System')
#
#         lbl_title = Label(self.root, text='EMPLOYEE MANAGEMENT SYSTEM', font=('times new roman', 37, 'bold'),
#                           fg='red', bg='white')
#         lbl_title.place(x=0, y=0, width=1530, height=50)
#
#         img_logo = Image.open('collegephoto.py')
#         img_logo = img_logo.resize((50, 50), Image.ANTIALIAS)
#         self.photo_logo=ImageTK.photoImage(img_logo)
#
#         self.logo=Label(self.root,image=self.photo_logo)
#         self.logo.place(x=270,y=0,width=50,height=50)
#
#         img_frame = Frame(self.root, bd=2, relief=RIDGE, bg='white')
#         img_frame.place(x=0,y=50,width=1530,height =160)
#
#
# if __name__ == "__main__":
#     root = tk.Tk()
#     obj = Employee(root)
#     root.mainloop() */
