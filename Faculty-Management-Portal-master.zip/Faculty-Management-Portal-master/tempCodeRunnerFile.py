from flask import Flask, render_template, request, session, redirect
from flask_pymongo import PyMongo
from flaskext.mysql import MySQL
import bcrypt

app = Flask(__name__)

# MongoDB configuration
app.config['MONGO_DBNAME'] = 'LeaveManagement'
app.config['MONGO_URI'] = 'mongodb://localhost:27017/'

try:
    mongo = PyMongo(app)
    if mongo.db:
        print("MongoDB connected successfully")
    else:
        print("Failed to connect to MongoDB")
except Exception as e:
    print(f"Error initializing PyMongo: {e}")